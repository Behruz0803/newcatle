# Newcastle School — lokal versiya

1. Node.js o'rnating (https://nodejs.org, 18 yoki yangiroq).
2. Windows: `start.bat` ustiga ikki marta bosing.  Mac/Linux: `./start.sh` yoki `node server.js`.
3. Brauzerda http://localhost:3000 ochiladi.

- Ma'lumotlar `data/db.json` faylida saqlanadi (birinchi ishga tushishda demo-data.json dan nusxa olinadi).
- Demo ma'lumotni qayta tiklash: `data/db.json` ni o'chirib, serverni qayta ishga tushiring.
- Login/parollar: `demo-accounts.md` (masalan: admin / vmTw427CPG).
- Firebase endi kerak emas, internet ham shart emas (faqat tarjima funksiyasi MyMemory API ishlatadi).
